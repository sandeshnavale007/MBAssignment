import { HttpErrorResponse } from '@angular/common/http';
import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup } from '@angular/forms';
import { AppComponent } from 'src/app/app.component';
import { UserServiceService } from 'src/app/service/user-service.service';

@Component({
  selector: 'app-employee',
  templateUrl: './employee.component.html',
  styleUrls: ['./employee.component.css']
})
export class EmployeeComponent implements OnInit {

  public employees = [];
  addEmployeeForm: FormGroup;
  display = "none";
  displayDeletePopUp = "none";
  selectedId;Any;
  isEdit:boolean=false;

    constructor(private fb: FormBuilder, private _employeeSerice : UserServiceService) {  }
  
    ngOnInit() {
      this.getData();
      this.addEmployeeForm = this.fb.group({
        id: [''],
        firstname:[''],
        lastname:[''],
        address:[''],
        mobile:[''],
        city:['']
       });
    }
  
  
    getData(){
      this._employeeSerice.requestData('get', 'employee/')
      .subscribe((res) => {
        if (res.code==200) {
         this.employees=res.data;
        } else {
          this.employees=[];
        }
      })
    }


    onSubmit(data){
      this._employeeSerice.requestData('post', 'employee/', data)
      .subscribe((res) => {
        if (res.code==200) {
          alert("Employee Added Sucessfully");
          this.display = "none";
          this.resetForm();
          this.getData();
          this.isEdit=false
        } else {
          alert(res.message)
        }
      },(error: HttpErrorResponse) => {
        
      });
    }
    remove(){
      let body ={
        id:this.selectedId
      }
      this._employeeSerice.requestData('post', 'employee/removeEmployee', body)
      .subscribe((res) => {
        if (res.code==200) {
          alert(res.data);
          this.onCloseHandledDelete();
          this.getData();
        } else {
          alert(res.message)
        }
      })
    }
    edit(id:number){
      let body ={
        id:id
      }
      this._employeeSerice.requestData('post', 'employee/getEmployeeById', body)
      .subscribe((res) => {
        if (res.code==200) {
        this.addEmployeeForm.patchValue({
          id: res.data.id,
          firstname:res.data.firstname,
          lastname:res.data.lastname,
          address:res.data.address,
          mobile:res.data.mobile,
          city:res.data.city
         });
         this.display = "block";
        } else {
          alert(res.message)
        }
      })
    }
    resetForm(){
      this.addEmployeeForm.patchValue({
        id: '',
        firstname:'',
        lastname:'',
        address:'',
        mobile:'',
        city:''
       });
    }
    openModal() {
      this.display = "block";
    }
    onCloseHandled() {
      this.isEdit=false
      this.display = "none";
    }

    deletePopUp(id) {
      this.selectedId=id;
      this.displayDeletePopUp = "block";
    }
    onCloseHandledDelete() {
      this.selectedId='';
      this.displayDeletePopUp = "none";
    }
  }
