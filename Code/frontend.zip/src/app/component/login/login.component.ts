import { Component, OnInit } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { AppComponent } from 'src/app/app.component';
import { UserServiceService } from 'src/app/service/user-service.service';

@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  logIn: FormGroup;
  registrationForm: FormGroup;
  registrationStatus:boolean=false;
  invalid:boolean;

  constructor(private fb: FormBuilder, private router: Router,private service: UserServiceService, private alert : AppComponent) { }

  ngOnInit(){
    if (this.service.loggedIn()) {
        this.router.navigate(['/employee']);
    }
    this.logIn=this.fb.group({
      username:['', Validators.required ],
      password:['', Validators.required ],
     });

     this.registrationForm=this.fb.group({
      firstname:['', Validators.required ],
      lastName:['', Validators.required ],
      email:['', Validators.required ],
      password:['', Validators.required ],
      dob:['', Validators.required ],
      company:['', Validators.required ],
     });
  }
  get fval() {
    return this.registrationForm.controls;
  }
  get logval() {
    return this.logIn.controls;
  }

  getToday(): string {
    return new Date().toISOString().split('T')[0]
 }
 
  login(data) {
    this.invalid = false;
    if (this.logIn.invalid) {
      this.invalid=true
      return;
    }
      this.service
        .requestData('post', 'employee/login', data)
        .subscribe((res) => {
          if (res.code==200) {
              localStorage.setItem('MBToken',res.data.token)
              this.router.navigate(['/employee']);
          } else {
            alert(res.message)
          }
        });
    }
  
    registration(data) {
      this.invalid = false;
      if (this.registrationForm.invalid) {
        this.invalid=true
        return;
      }
      this.service
        .requestData('post', 'employee/addManager', data)
        .subscribe((res) => {
          if (res.code==200) {
             alert(res.data)
             this.registrationStatus=false;
          } else {
            alert(res.message)
          }
        });
    }
} 
