import { NgModule } from '@angular/core';
import { Routes, RouterModule } from '@angular/router';
import { EmployeeComponent } from './component/employee/employee.component';
import { HomeComponent } from './component/home/home.component';
import { LoginComponent } from './component/login/login.component';
import { SubscriptionComponent } from './component/subscription/subscription.component';
import { AuthGuard } from './service/auth.guard';


const routes: Routes = [
  {path:'', component:LoginComponent, pathMatch:"full"},
  {path:'login', component:LoginComponent},
  {path:'', component:HomeComponent,
    children:[ 
      {path:'home',canActivate:[AuthGuard], component:HomeComponent},
      {path:'employee',canActivate:[AuthGuard], component:EmployeeComponent},
      {path:'subscription',canActivate:[AuthGuard], component:SubscriptionComponent},
  //  {path:'excel',canActivate:[AuthGuard], component:UploadExcelComponent}
    ]
    },
];

@NgModule({
  imports: [RouterModule.forRoot(routes)],
  exports: [RouterModule]
})
export class AppRoutingModule { }
