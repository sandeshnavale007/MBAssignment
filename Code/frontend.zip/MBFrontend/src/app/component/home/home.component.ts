import { Component, OnInit } from '@angular/core';
import { Router } from '@angular/router';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  menuList=[
    // {
    //   id:1,
    //   routerLink: '/home',
    //   name:"Dashboard"
    // },
    {
      id:2,
      routerLink: '/employee',
      name:"Employee"
    },{
      id:3,
      routerLink: '/subscription',
      name:"Subscription Management"
    }
  ]
  constructor( private router: Router) { }

  ngOnInit(): void {
  }
  
  logout() {
    localStorage.removeItem('token');
    this.router.navigate(['/login']);
  }
}
