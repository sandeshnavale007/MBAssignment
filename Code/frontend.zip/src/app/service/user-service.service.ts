import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { HttpClient, HttpErrorResponse } from "@angular/common/http";
import {  throwError } from 'rxjs';
import { catchError } from 'rxjs/operators';
import { environment } from 'src/environments/environment';

@Injectable({
  providedIn: 'root'
})
export class UserServiceService {
  baseURl = environment.baseUrl;
  status = 'online';
  isConnected = true;  

  constructor(private httpClient: HttpClient) {}

  requestData(
    type: string,
    api: string,
    body: any = '',
    apiType?
  ): Observable<any> {
    if (type == 'get') {
      let params = '';
      if (body) {
        params += '?';
        for (var key in body) {
          if ((body[key] + '').length > 0 && body[key] != undefined) {
            params += key + '=' + body[key] + '&';
          }
        }
      }
      return this.httpClient.get(this.baseURl + api + params).pipe(catchError(this.handleError));
    } else if (type == 'post') {
      return this.httpClient.post(this.baseURl + api, body).pipe(catchError(this.handleError));
    } else if (type == 'put') {
      return this.httpClient.put(this.baseURl + api, body);
    } else if (type == 'delete') {
      return this.httpClient.delete(this.baseURl + api, body).pipe(catchError(this.handleError));
    }
    return;
  }
  getToken(){
    return localStorage.getItem('MBToken')
  }
  loggedIn(){
    console.log(localStorage.getItem('MBToken'));
    return !!localStorage.getItem('MBToken')
  }

  handleError(error: HttpErrorResponse) {
    // console.log(error.error.message,"======")
    let errorMessage = 'Unknown error!';
    if (error.error instanceof ErrorEvent) {
      // Client-side errors
      errorMessage = error?.error?.message;
    } else {
      // Server-side errors
      errorMessage = error?.error?.message;
    }
    window.alert(errorMessage);
    return throwError(errorMessage);
  }

}
