import { HttpEvent, HttpHandler, HttpInterceptor, HttpRequest } from '@angular/common/http';
import { Injectable } from '@angular/core';
import { Observable } from 'rxjs';
import { UserServiceService } from './user-service.service';

@Injectable({
  providedIn: 'root'
})
export class InterceptorService  implements HttpInterceptor {

  constructor(public auth: UserServiceService) { }
  intercept(request: HttpRequest<any>, next: HttpHandler): Observable<HttpEvent<any>> {

    console.log(request.url,"this.auth.getToken()")
      //Check for url. If it is login url then return    
      if (request.url.includes('/login') || request.url.includes('/addManager')  ) {
        console.log("============")
         return next.handle(request);
      }
      request = request.clone({
          setHeaders: {
              Authorization: this.auth.getToken()
          }
      });
      return next.handle(request);
  }
}
