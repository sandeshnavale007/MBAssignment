import { Component, OnInit } from '@angular/core';
import { UserServiceService } from 'src/app/service/user-service.service';

@Component({
  selector: 'app-subscription',
  templateUrl: './subscription.component.html',
  styleUrls: ['./subscription.component.css']
})
export class SubscriptionComponent implements OnInit {  
  
  subscriptionList:any=[]

  constructor( private service: UserServiceService) { }
  handler:any = null;
  ngOnInit() { 
    this.fetchSubscriptionList();
   }
 

  fetchSubscriptionList() {

    this.service
      .requestData('get', 'employee/subscription')
      .subscribe((res) => {
        if (res.code==200) {
           console.log(res)
           this.subscriptionList=res.data?res.data:[];
        } else {
          alert(res.message)
        }
      });
  }


  pay(amount,id,title,details) {    
    var that = this;
    var handler = (<any>window).StripeCheckout.configure({
      key: 'pk_test_51Iaed1SGQDLKU2L0iWRnjHGS6B7dcnr8VXnyYNakRVRDBX82H3ds78H2oXZemugLYsDztaHO6xQI4jubEtskWtn600DUh50A5B',
      locale: 'auto',
      token: function (token: any) {
        that.paymentRequest(token.id,amount,token.card.id,token.created,token.email,id);
        console.log(token)
      }
    });
 
    handler.open({
      name: title,
      description: details,
      amount: amount * 100
    });
  }
 
  paymentRequest(token,amount,card,date,email,id) {
    console.log("================")
    let body = {
      token:token,
      cardId:card,
      tokenCreated:date,
      amount:amount, 
      subscriptionId:id
    }
    this.service
      .requestData('post', 'employee/stripeToken', body)
      .subscribe((res) => {
        if (res.code==200) {
          this.fetchSubscriptionList();
          alert("subscribe sucessfully")
        } else {
          alert(res.message)
        }
      });
  }


  cancelSubscribed(id){
    console.log("================")
    let body = {
      id:id
    }
    this.service
      .requestData('post', 'employee/unsubscripbed', body)
      .subscribe((res) => {
        if (res.code==200) {
          alert("Unsubscribe sucessfully")
          this.fetchSubscriptionList();
        } else {
          alert(res.message)
        }
      });
  
  }



  
}
